---
name: donation-management-system
description: >
  Generates complete Spring Boot MVC code for the Event-Driven Blood & Organ Donation Management System.
  Use this skill whenever the user asks to write code, create files, implement features, or build any 
  layer (Model, View, Controller, Service, Repository) for the donation project. Also triggers for 
  questions about GRASP principles, design patterns (Factory, Observer, Singleton, Strategy), 
  MVC architecture, entity design, Thymeleaf templates, or MySQL schema for this project.
  Always use this skill when any team member (Sharath, Nandani, Nandan, Neha) asks to implement their part.
---

# Donation Management System — Code Generation Skill

## Project Identity
- **Name:** Event-Driven Blood & Organ Donation Management System
- **Stack:** Spring Boot 4.0.5 · Java 23 · MySQL · Thymeleaf · Spring Data JPA
- **Package root:** `com.donation.system`
- **DB name:** `donationdb`
- **Port:** `8080`

---

## Team → Code Ownership

| Member | SRN | Entities | Pattern | GRASP |
|--------|-----|----------|---------|-------|
| Sharath | 823 | User, Request | Factory (RequestFactory) | Creator (User creates Request) |
| Nandani | 364 | Donor, Patient | Observer (DonationEvent publisher/listener) | Information Expert (Donor knows own availability) |
| Nandan | 363 | Admin, Donation | Singleton (EventManager) | Controller (Admin controls all operations) |
| Neha | 379 | Inventory | Strategy (HighPriorityMatchingStrategy vs NormalMatchingStrategy) | Low Coupling (Inventory independent of other modules) |

---

## Entity -> Owner Mapping (Exact Division)

| Entity | Owner |
|--------|-------|
| User | Sharath (823) |
| Donor | Nandani (364) |
| Patient | Nandani (364) |
| Admin | Nandan (363) |
| Donation | Nandan (363) |
| Request | Sharath (823) |
| Inventory | Neha (379) |

---

## MVC Layer Structure

```
com.donation.system/
├── model/
│   ├── entity/        → JPA entities (User, Donor, Patient, Admin, Donation, Request, Inventory)
│   ├── dto/           → Data Transfer Objects
│   └── enums/         → BloodType, RequestStatus, DonationType
├── repository/        → JPA interfaces extending JpaRepository
├── service/           → Business logic + design patterns
│   ├── factory/       → RequestFactory (Sharath)
│   ├── observer/      → DonationObserver, DonationSubject (Nandani)
│   ├── singleton/     → EventManager (Nandan)
│   └── strategy/      -> MatchingStrategy, HighPriorityMatchingStrategy, NormalMatchingStrategy (Neha)
├── controller/        → @Controller classes per member
└── resources/
    ├── templates/     → Thymeleaf HTML per feature
    └── application.properties
```

---

## Entity Class Diagram (Source of Truth)

```
User (base)
  - userID: int
  - name: String
  - mail: String
  - password: String
  - phone: int
  + login(), register(), updateProfile()

Donor extends User [364-Nandani]
  - bloodType: String
  - organType: String
  - availability: boolean
  + donateBlood(), donateOrgan(), viewDonationStatus()

Patient extends User [364-Nandani]
  - requiredBloodType: String
  - requiredOrgan: String
  - urgencyLevel: String
  + requestBlood(), requestOrgan(), trackRequestStatus()

Admin extends User [363-Nandan]
  - adminID: int
  + manageUsers(), recordDonation(), updateInventory()
  + generateReports(), generateAISummary()

Donation [363-Nandan]
  - donationID: int
  - donationType: String
  - date: Date
  - quantity: int
  - status: String
  + updateStatus()

Request [823-Sharath]
  - requestID: int
  - requestType: String
  - requestDate: Date
  - status: String
  + updateRequestStatus()

Inventory [379-Neha]
  - bloodType: String
  - organType: String
  - quantity: int
  + addStock(), reduceStock(), checkAvailability()
```

---

## Inheritance Strategy
Use **Single Table Inheritance** (`@Inheritance(strategy = InheritanceType.SINGLE_TABLE)`)
- One `users` table with `dtype` discriminator column
- Simpler queries, fewer joins

---

## Design Patterns — Implementation Rules

### 1. Factory Pattern (Sharath — Request)
```java
// RequestFactory.createRequest(id, "BLOOD"/"ORGAN", detail)
// Returns BloodRequest or OrganRequest (both extend Request)
// GRASP Creator: User/Patient initiates request creation, factory chooses subtype
```

### 2. Observer Pattern (Nandani — Donor/Patient)
```java
// Donor publishes DonationEvent when a donation is available
// Patient listens to DonationEvent and reacts
// Use Spring ApplicationEvent as the event bus
```

### 3. Singleton Pattern (Nandan — EventManager)
```java
// EventManager.getInstance() — thread-safe double-checked locking
// Also: @Component with @Scope("singleton") acceptable in Spring context
```

### 4. Strategy Pattern (Neha — Inventory)
```java
// MatchingStrategy interface → match(Donation, List<Request>)
// HighPriorityMatchingStrategy → urgency-based (CRITICAL > HIGH > NORMAL)
// NormalMatchingStrategy → FIFO order
// Inventory holds reference to strategy, swappable at runtime
```

---

## application.properties (Fixed Config)
```properties
spring.datasource.url=jdbc:mysql://localhost:3306/donationdb
spring.datasource.username=root
spring.datasource.password=nandand14
spring.jpa.hibernate.ddl-auto=update
spring.jpa.show-sql=true
spring.thymeleaf.cache=false
server.port=8080
spring.jpa.properties.hibernate.dialect=org.hibernate.dialect.MySQLDialect
```

---

## Code Generation Rules

When generating code for this project ALWAYS:
1. Use `jakarta.*` imports (NOT `javax.*`) — Spring Boot 4.x requirement
2. Add Lombok annotations (`@Data`, `@NoArgsConstructor`, `@AllArgsConstructor`) on entities
3. Use `@Inheritance(strategy = InheritanceType.SINGLE_TABLE)` on User entity
4. Each controller method maps to one use case owned by that member
5. Thymeleaf templates go in `src/main/resources/templates/[member-feature]/`
6. Every service class must show WHERE the design pattern is applied (comment it)
7. Repository interfaces only — no custom SQL unless needed
8. Use `Optional<T>` in service layer for null safety

## Code Generation Order (per member session)
1. Entity class (`model/entity/`)
2. Repository interface (`repository/`)
3. Service class with pattern (`service/`)
4. Controller (`controller/`)
5. Thymeleaf HTML (`templates/`)

---

## MySQL Schema (auto-generated by JPA, but reference)
```sql
-- users table (single table inheritance)
CREATE TABLE users (
  dtype VARCHAR(31), user_id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(255), mail VARCHAR(255), password VARCHAR(255), phone INT,
  blood_type VARCHAR(10), organ_type VARCHAR(50), availability BOOLEAN,
  required_blood_type VARCHAR(10), required_organ VARCHAR(50), urgency_level VARCHAR(20),
  admin_id INT
);

CREATE TABLE donations (
  donation_id INT PRIMARY KEY AUTO_INCREMENT,
  donation_type VARCHAR(20), date DATE, quantity INT, status VARCHAR(20),
  donor_id INT, FOREIGN KEY (donor_id) REFERENCES users(user_id)
);

CREATE TABLE requests (
  request_id INT PRIMARY KEY AUTO_INCREMENT,
  request_type VARCHAR(20), request_date DATE, status VARCHAR(20),
  patient_id INT, FOREIGN KEY (patient_id) REFERENCES users(user_id)
);

CREATE TABLE inventory (
  id INT PRIMARY KEY AUTO_INCREMENT,
  blood_type VARCHAR(10), organ_type VARCHAR(50), quantity INT
);
```

---

## Navigation
- For full entity code → generate with Lombok + JPA annotations
- For pattern implementations → see Design Patterns section above
- For HTML templates → use Thymeleaf with Bootstrap 5 CDN
- For PDF report → include architecture explanation + code screenshots