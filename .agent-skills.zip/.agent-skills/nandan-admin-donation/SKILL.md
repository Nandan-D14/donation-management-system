---
name: nandan-admin-donation
description: >
  Code generation skill for Nandan (SRN 363) — Admin & Donation module with Singleton pattern.
  Covers Admin entity, Donation entity, EventManager (Singleton), admin dashboard, donation recording,
  user management, inventory updates, report generation, and AI summary features.
---

# Nandan — Admin & Donation Module (SRN 363)

## Responsibilities
| Area | Details |
|------|---------|
| **Entities** | `Admin`, `Donation` |
| **Pattern** | Singleton (`EventManager`) |
| **GRASP** | Controller |
| **Use Cases** | Manage users, record donations, update inventory, generate reports, AI summary |

---

## Entity: Admin (extends User)

```
Admin extends User
  - adminID: int
  + manageUsers()
  + recordDonation()
  + updateInventory()
  + generateReports()
  + generateAISummary()
```

**File:** `com/donation/system/model/entity/Admin.java`
- `@Entity`, `@DiscriminatorValue("Admin")`
- `@Data`, `@NoArgsConstructor`, `@AllArgsConstructor` (Lombok)
- `adminID` as `@Id @GeneratedValue`

---

## Entity: Donation

```
Donation
  - donationID: int
  - donationType: String (BLOOD / ORGAN)
  - date: Date
  - quantity: int
  - status: String (PENDING / COMPLETED / CANCELLED)
  - donor (ManyToOne → User)
  + updateStatus()
```

**File:** `com/donation/system/model/entity/Donation.java`
- `@Entity`, `@Table(name = "donations")`
- `@Data`, `@NoArgsConstructor`, `@AllArgsConstructor` (Lombok)
- `@ManyToOne` relationship to `Donor`/`User`

---

## Singleton Pattern — EventManager

```java
// Thread-safe double-checked locking
public class EventManager {
    private static volatile EventManager instance;
    private List<DonationEvent> events = new ArrayList<>();

    private EventManager() {}

    public static EventManager getInstance() {
        if (instance == null) {
            synchronized (EventManager.class) {
                if (instance == null) {
                    instance = new EventManager();
                }
            }
        }
        return instance;
    }

    public void logEvent(DonationEvent event) { events.add(event); }
    public List<DonationEvent> getEvents() { return events; }
}
```

**Alternative (Spring way):** `@Component` + `@Scope("singleton")`

**File:** `com/donation/system/service/singleton/EventManager.java`

---

## MVC Structure

```
com.donation.system/
├── model/entity/
│   ├── Admin.java
│   └── Donation.java
├── repository/
│   ├── AdminRepository.java
│   └── DonationRepository.java
├── service/
│   ├── singleton/
│   │   └── EventManager.java
│   ├── AdminService.java
│   └── DonationService.java
├── controller/
│   └── AdminController.java
└── resources/templates/
    ├── admin/
    │   └── dashboard.html
    └── donations/
        ├── list.html
        └── record.html
```

---

## Code Generation Rules (Nandan)
1. `Admin` uses `@DiscriminatorValue("Admin")` — single table inheritance from `User`
2. `Donation` has `@ManyToOne` to `Donor` (FK: `donor_id`)
3. `EventManager` MUST use double-checked locking OR `@Component` singleton
4. Admin controller methods: `manageUsers()`, `recordDonation()`, `updateInventory()`, `generateReports()`
5. Thymeleaf templates use Bootstrap 5 CDN
6. Service layer uses `Optional<T>` for null safety
7. Use `jakarta.*` imports (NOT `javax.*`)
8. Comment WHERE Singleton pattern is applied in EventManager
9. **GRASP (Controller) MUST be implemented and documented:**
  - `AdminController` MUST have Javadoc: `/** GRASP: Controller Pattern */`
   - Controllers ONLY handle UI events — delegate ALL business logic to services
   - Controllers MUST NOT contain business logic (no calculations, no DB operations)
   - Add `@author Nandan (SRN 363)` on every class

---

## GRASP: Controller Pattern (MUST Implement)

**What:** Controllers are the "first handler" for system events. They receive UI/web requests and delegate to the right service.

**How to apply:**
```java
/**
 * GRASP: Controller Pattern
 * AdminController handles all system events/UI requests related to Admin management.
 * It delegates business logic to AdminService (Information Expert).
 *
 * @author Nandan (SRN 363)
 */
@Controller
@RequestMapping("/admin")
public class AdminController {
    private final AdminService adminService;  // Inject Information Expert
    // ... only delegates — no business logic here
}
```

**Rules:**
- `AdminController` is the central GRASP Controller for this module and must have GRASP Javadoc
- Every controller method MUST delegate to a service (Information Expert)
- Controllers are thin — they coordinate, they don't compute

---

## Admin Controller Endpoints
| Method | Path | Description |
|--------|------|-------------|
| GET | `/admin/dashboard` | Admin dashboard overview |
| GET | `/admin/users` | List all users |
| GET | `/admin/users/{id}` | View user details |
| POST | `/admin/donations/record` | Record a new donation |
| GET | `/admin/donations` | List all donations |
| GET | `/admin/reports` | Generate reports |

---

## MySQL (reference — auto-generated by JPA)
```sql
-- Admin inherits from users table (dtype = 'Admin')
-- donations table:
CREATE TABLE donations (
  donation_id INT PRIMARY KEY AUTO_INCREMENT,
  donation_type VARCHAR(20), date DATE, quantity INT, status VARCHAR(20),
  donor_id INT, FOREIGN KEY (donor_id) REFERENCES users(user_id)
);
```

---

## Navigation
- Project skill → see `.agent-skills/about-this-proejct/SKILL.md`
- Other members → `nandani-donor-patient.md`, `sharath-user-request.md`, `neha-inventory.md`
