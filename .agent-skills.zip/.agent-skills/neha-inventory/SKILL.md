---
name: neha-inventory
description: >
  Code generation skill for Neha (SRN 379) — Inventory module with Strategy pattern.
    Covers Inventory entity, MatchingStrategy interface, HighPriorityMatchingStrategy, NormalMatchingStrategy,
  stock management (add/reduce/check), and donation-request matching algorithms.
---

# Neha — Inventory Module (SRN 379)

## Responsibilities
| Area | Details |
|------|---------|
| **Entities** | `Inventory` |
| **Pattern** | Strategy (`HighPriorityMatchingStrategy` vs `NormalMatchingStrategy`) |
| **GRASP** | Low Coupling (Inventory independent of Donor/Patient/Admin modules) |
| **Use Cases** | Add stock, reduce stock, check availability, match donations to requests, strategy switching |

---

## Entity: Inventory

```
Inventory
  - id: int
  - bloodType: String
  - organType: String
  - quantity: int
  + addStock(int amount)
  + reduceStock(int amount)
  + checkAvailability(): boolean
```

**File:** `com/donation/system/model/entity/Inventory.java`
- `@Entity`, `@Table(name = "inventory")`
- `@Data`, `@NoArgsConstructor`, `@AllArgsConstructor` (Lombok)
- Holds reference to `MatchingStrategy` for matching operations

---

## Strategy Pattern Implementation

### Strategy Interface
```java
public interface MatchingStrategy {
    List<Request> match(Donation donation, List<Request> pendingRequests);
}
```

**File:** `com/donation/system/service/strategy/MatchingStrategy.java`

---

### High Priority Strategy (Urgency-Based)
```java
@Component
public class HighPriorityMatchingStrategy implements MatchingStrategy {

    @Override
    public List<Request> match(Donation donation, List<Request> pendingRequests) {
        return pendingRequests.stream()
            .filter(req -> matchesType(donation, req))
            .sorted(Comparator.comparingInt(this::urgencyPriority))
            .limit(donation.getQuantity())
            .collect(Collectors.toList());
    }

    private int urgencyPriority(Request r) {
        // Lower number = higher priority (sorted ascending)
        return switch (r.getUrgencyLevel()) {
            case "CRITICAL" -> 1;
            case "HIGH"     -> 2;
            case "NORMAL"   -> 3;
            default         -> 4;
        };
    }

    private boolean matchesType(Donation d, Request r) {
        // Match blood type or organ type
        return d.getDonationType().equals(r.getRequestType());
    }
}
```

**File:** `com/donation/system/service/strategy/HighPriorityMatchingStrategy.java`

---

### Normal Strategy (FIFO Order)
```java
@Component
public class NormalMatchingStrategy implements MatchingStrategy {

    @Override
    public List<Request> match(Donation donation, List<Request> pendingRequests) {
        return pendingRequests.stream()
            .filter(req -> matchesType(donation, req))
            .sorted(Comparator.comparing(Request::getRequestDate))
            .limit(donation.getQuantity())
            .collect(Collectors.toList());
    }

    private boolean matchesType(Donation d, Request r) {
        return d.getDonationType().equals(r.getRequestType());
    }
}
```

**File:** `com/donation/system/service/strategy/NormalMatchingStrategy.java`

---

### InventoryService (Strategy Context — Swappable at Runtime)
```java
@Service
public class InventoryService {

    private MatchingStrategy strategy;
    private final InventoryRepository inventoryRepo;
    private final RequestRepository requestRepo;

    public InventoryService(InventoryRepository inventoryRepo, RequestRepository requestRepo) {
        this.inventoryRepo = inventoryRepo;
        this.requestRepo = requestRepo;
    }

    // Strategy can be swapped at runtime
    public void setStrategy(MatchingStrategy strategy) {
        this.strategy = strategy;
    }

    public List<Request> matchDonationToRequests(Donation donation) {
        List<Request> pending = requestRepo.findByStatus("PENDING");
        return strategy.match(donation, pending);
    }

    public void addStock(String bloodType, String organType, int amount) {
        Inventory inv = inventoryRepo.findByBloodTypeAndOrganType(bloodType, organType);
        if (inv == null) {
            inv = new Inventory();
            inv.setBloodType(bloodType);
            inv.setOrganType(organType);
        }
        inv.setQuantity(inv.getQuantity() + amount);
        inventoryRepo.save(inv);
    }

    public boolean reduceStock(String bloodType, String organType, int amount) {
        Inventory inv = inventoryRepo.findByBloodTypeAndOrganType(bloodType, organType);
        if (inv != null && inv.getQuantity() >= amount) {
            inv.setQuantity(inv.getQuantity() - amount);
            inventoryRepo.save(inv);
            return true;
        }
        return false;
    }

    public boolean checkAvailability(String bloodType, String organType, int amount) {
        Inventory inv = inventoryRepo.findByBloodTypeAndOrganType(bloodType, organType);
        return inv != null && inv.getQuantity() >= amount;
    }
}
```

**File:** `com/donation/system/service/InventoryService.java`

---

## MVC Structure

```
com.donation.system/
├── model/entity/
│   └── Inventory.java
├── repository/
│   └── InventoryRepository.java
├── service/
│   ├── strategy/
│   │   ├── MatchingStrategy.java
│   │   ├── HighPriorityMatchingStrategy.java
│   │   └── NormalMatchingStrategy.java
│   └── InventoryService.java
├── controller/
│   └── InventoryController.java
└── resources/templates/
    └── inventory/
        ├── dashboard.html
        ├── stock.html
        └── matching.html
```

---

## Code Generation Rules (Neha)
1. `Inventory` is a standalone entity (no inheritance)
2. `MatchingStrategy` is an **interface** — implemented by concrete strategies
3. Strategies MUST be `@Component` for Spring DI
4. `InventoryService` holds a **swappable** strategy reference (set at runtime)
5. `HighPriorityMatchingStrategy` sorts by urgency: CRITICAL > HIGH > NORMAL
6. `NormalMatchingStrategy` sorts by request date (FIFO)
7. Comment WHERE Strategy pattern is applied in service classes
8. Thymeleaf templates use Bootstrap 5 CDN
9. Use `jakarta.*` imports (NOT `javax.*`)
10. Service layer uses `Optional<T>` for null safety
11. **GRASP (Low Coupling) MUST be implemented and documented:**
    - `InventoryService` MUST have Javadoc: `/** GRASP: Low Coupling */`
    - Use interfaces (`MatchingStrategy`) instead of concrete classes for dependencies
    - Strategy classes are independent — no direct coupling between them
    - `Inventory` module must NOT directly depend on Donor/Patient/Admin entities
    - `InventoryService` depends only on the `MatchingStrategy` interface, not concrete implementations
    - Constructor injection (NOT field injection) for all dependencies
    - Add `@author Neha (SRN 379)` on every class

---

## Inventory Controller Endpoints
| Method | Path | Description |
|--------|------|-------------|
| GET | `/inventory/dashboard` | Inventory overview |
| GET | `/inventory/stock` | View current stock levels |
| POST | `/inventory/stock/add` | Add stock |
| POST | `/inventory/stock/reduce` | Reduce stock |
| GET | `/inventory/matching` | View donation-request matches |
| POST | `/inventory/matching/strategy` | Switch matching strategy |

---

## MySQL (reference — auto-generated by JPA)
```sql
CREATE TABLE inventory (
  id INT PRIMARY KEY AUTO_INCREMENT,
  blood_type VARCHAR(10), organ_type VARCHAR(50), quantity INT
);
```

---

## Navigation
- Project skill → see `.agent-skills/about-this-proejct/SKILL.md`
- Other members → `nandan-admin-donation.md`, `nandani-donor-patient.md`, `sharath-user-request.md`
