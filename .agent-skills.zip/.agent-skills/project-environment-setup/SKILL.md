---
name: project-environment-setup
description: >
  Environment setup guide for the Event-Driven Blood & Organ Donation Management System.
  Use this skill when setting up the project, installing dependencies, configuring MySQL,
  running the application, or troubleshooting startup issues.
---

# Project Environment Setup Guide

## Prerequisites

| Tool | Version | How to Check |
|------|---------|--------------|
| **JDK** | 21+ | `java -version` |
| **Maven** | 3.8+ | `mvn -version` (or use `mvnw`) |
| **MySQL** | 8.0+ | `mysql --version` |
| **Git** | 2.30+ | `git --version` |

---

## Step 1 — MySQL Setup

### 1.1 Start MySQL Service
**Windows:**
```cmd
net start MySQL80
```

**Verify it's running:**
```cmd
mysql -u root -p -e "SELECT 1;"
```

### 1.2 Create Database
```sql
CREATE DATABASE donationdb;
```

### 1.3 Verify Credentials
Update `src/main/resources/application.properties`:
```properties
spring.datasource.url=jdbc:mysql://localhost:3306/donationdb
spring.datasource.username=root
spring.datasource.password=YOUR_PASSWORD_HERE
spring.jpa.hibernate.ddl-auto=update
spring.jpa.show-sql=true
spring.thymeleaf.cache=false
server.port=8080
spring.jpa.properties.hibernate.dialect=org.hibernate.dialect.MySQLDialect
```

---

## Step 2 — Clone & Build

### 2.1 Clone Repository
```bash
git clone https://github.com/Nandan-D14/donation-management-system.git
cd donation-management-system
```

### 2.2 Build Project
```bash
# Using Maven wrapper (recommended)
./mvnw clean package

# Or on Windows cmd
mvnw.cmd clean package
```

### 2.3 Run Tests
```bash
./mvnw test
```

---

## Step 3 — Run Application

### 3.1 Using Maven Wrapper
```bash
./mvnw spring-boot:run
```

### 3.2 Using IDE
- Import as Maven project in IntelliJ IDEA / VS Code / Eclipse
- Run `DonationManagementSystemApplication.java`

### 3.3 Verify It's Running
```bash
curl http://localhost:8080/
```
Expected: `index.html` page loads (or 404 if no controller exists yet)

---

## Step 4 — Git Workflow

### 4.1 Branch Strategy
```
main                    ← Stable, production-ready code
├── feature/singleton   ← Nandan (Admin, Donation, EventManager)
├── feature/observer    ← Nandani (Donor, Patient, Observer)
├── feature/factory     ← Sharath (User, Request, Factory)
└── feature/strategy    ← Neha (Inventory, Strategy)
```

### 4.2 Create Feature Branch
```bash
git checkout -b feature/<member-name>
git push -u origin feature/<member-name>
```

### 4.3 Commit & Push
```bash
git add .
git commit -m "feat: <description of what you built>"
git push origin feature/<branch-name>
```

### 4.4 Merge to Main
1. Create Pull Request on GitHub
2. Code review
3. Merge via squash or merge commit

---

## Step 5 — Common Errors & Fixes

### Error: `Access denied for user 'root'@'localhost'`
**Fix:** Update password in `application.properties`:
```properties
spring.datasource.password=YOUR_ACTUAL_MYSQL_PASSWORD
```

### Error: `Port 8080 already in use`
**Fix:** Kill the process or change port:
```cmd
# Find process on port 8080
netstat -ano | findstr :8080
taskkill /PID <PID> /F

# Or change port in application.properties
server.port=8081
```

### Error: `No resource found for request '/'`
**Fix:** Create a controller mapping:
```java
@Controller
public class HomeController {
    @GetMapping("/")
    public String home() { return "index"; }
}
```

### Error: `ClassNotFoundException: jakarta.persistence.*`
**Fix:** Ensure `spring-boot-starter-data-jpa` dependency is in `pom.xml`

### Error: Tables not created in database
**Fix:** Ensure `spring.jpa.hibernate.ddl-auto=update` is set in `application.properties`

---

## Step 6 — Project Structure

```
donation-management-system/
├── .agent-skills/          ← AI agent skill files (ignored by git)
├── .gitignore
├── pom.xml
├── src/
│   ├── main/
│   │   ├── java/com/donation/system/
│   │   │   ├── DonationManagementSystemApplication.java
│   │   │   ├── model/
│   │   │   │   ├── entity/       ← JPA entities
│   │   │   │   ├── dto/          ← Data transfer objects
│   │   │   │   └── enums/        ← BloodType, RequestStatus, etc.
│   │   │   ├── repository/       ← JPA interfaces
│   │   │   ├── service/
│   │   │   │   ├── factory/      ← RequestFactory (Sharath)
│   │   │   │   ├── observer/     ← DonationObserver (Nandani)
│   │   │   │   ├── singleton/    ← EventManager (Nandan)
│   │   │   │   └── strategy/     ← MatchingStrategy (Neha)
│   │   │   └── controller/       ← @Controller classes
│   │   └── resources/
│   │       ├── application.properties
│   │       └── templates/        ← Thymeleaf HTML files
│   └── test/
│       └── java/com/donation/system/
│           └── DonationManagementSystemApplicationTests.java
└── target/                 ← Build output (ignored by git)
```

---

## Step 7 — Useful Commands

| Task | Command |
|------|---------|
| Build | `./mvnw clean package` |
| Run | `./mvnw spring-boot:run` |
| Test | `./mvnw test` |
| Skip tests | `./mvnw spring-boot:run -DskipTests` |
| Clean build | `./mvnw clean install` |
| View SQL logs | Check console output (show-sql=true) |
| Check DB tables | `mysql -u root -p donationdb -e "SHOW TABLES;"` |

---

## Step 8 — Team Member Quick Start

Each member should:
1. Pull latest `main`
2. Create their feature branch: `git checkout -b feature/<name>`
3. Read their skill file in `.agent-skills/<member>/SKILL.md`
4. Build their layer: Entity → Repository → Service → Controller → Template
5. Commit & push: `git add . && git commit -m "feat: <description>" && git push`
6. Create PR to merge into `main`

---

## Navigation
- Project overview → `.agent-skills/about-this-proejct/SKILL.md`
- Nandan (Admin/Donation) → `.agent-skills/nandan-admin-donation/SKILL.md`
- Nandani (Donor/Patient) → `.agent-skills/nandani-donor-patient/SKILL.md`
- Sharath (User/Request) → `.agent-skills/sharath-user-request/SKILL.md`
- Neha (Inventory) → `.agent-skills/neha-inventory/SKILL.md`
