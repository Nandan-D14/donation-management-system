---
name: sharath-user-request
description: >
  Code generation skill for Sharath (SRN 823) — User & Request module with Factory pattern.
  Covers User entity, Request entity hierarchy, RequestFactory (BloodRequest/OrganRequest),
  authentication (login/register), request management, and status tracking.
---

# Sharath — User & Request Module (SRN 823)

## Responsibilities
| Area | Details |
|------|---------|
| **Entities** | `User` (base), `Request` (base), `BloodRequest`, `OrganRequest` |
| **Pattern** | Factory (`RequestFactory`) |
| **GRASP** | Creator (User creates Request) |
| **Use Cases** | User registration, login, create requests (blood/organ), manage request status |

---

## Entity: User (Base Class)

```
User (abstract base)
  - userID: int
  - name: String
  - mail: String
  - password: String
  - phone: int
  + login()
  + register()
  + updateProfile()
```

**File:** `com/donation/system/model/entity/User.java`
- `@Entity`, `@Table(name = "users")`
- `@Inheritance(strategy = InheritanceType.SINGLE_TABLE)`
- `@DiscriminatorColumn(name = "dtype")`
- `@Data`, `@NoArgsConstructor`, `@AllArgsConstructor` (Lombok)
- `abstract class` — extended by Donor, Patient, Admin

---

## Entity: Request (Base Class)

```
Request (abstract base)
  - requestID: int
  - requestType: String (BLOOD / ORGAN)
  - requestDate: Date
  - status: String (PENDING / MATCHED / FULFILLED / CANCELLED)
  - patient (ManyToOne → User)
  + updateRequestStatus()
```

**File:** `com/donation/system/model/entity/Request.java`

---

## Entity: BloodRequest (extends Request)

```
BloodRequest extends Request
  - bloodType: String
  - unitsRequired: int
  - unitsReceived: int
```

**File:** `com/donation/system/model/entity/BloodRequest.java`
- `@Entity`, `@DiscriminatorValue("BLOOD")`

---

## Entity: OrganRequest (extends Request)

```
OrganRequest extends Request
  - organType: String
  - compatibilityNotes: String
```

**File:** `com/donation/system/model/entity/OrganRequest.java`
- `@Entity`, `@DiscriminatorValue("ORGAN")`

---

## Factory Pattern — RequestFactory

```java
public class RequestFactory {

    public static Request createRequest(Long id, String type, String detail) {
        switch (type.toUpperCase()) {
            case "BLOOD":
                BloodRequest br = new BloodRequest();
                br.setRequestID(id);
                br.setBloodType(detail);
                br.setRequestDate(new Date());
                br.setStatus("PENDING");
                return br;

            case "ORGAN":
                OrganRequest or = new OrganRequest();
                or.setRequestID(id);
                or.setOrganType(detail);
                or.setRequestDate(new Date());
                or.setStatus("PENDING");
                return or;

            default:
                throw new IllegalArgumentException("Unknown request type: " + type);
        }
    }
}
```

**File:** `com/donation/system/service/factory/RequestFactory.java`

**Usage:**
```java
Request req = RequestFactory.createRequest(null, "BLOOD", "O+");
requestRepository.save(req);
```

---

## MVC Structure

```
com.donation.system/
├── model/entity/
│   ├── User.java
│   ├── Request.java
│   ├── BloodRequest.java
│   └── OrganRequest.java
├── repository/
│   ├── UserRepository.java
│   └── RequestRepository.java
├── service/
│   ├── factory/
│   │   └── RequestFactory.java
│   ├── UserService.java
│   └── RequestService.java
├── controller/
│   ├── AuthController.java
│   └── RequestController.java
└── resources/templates/
    ├── auth/
    │   ├── login.html
    │   └── register.html
    └── requests/
        ├── create.html
        ├── list.html
        └── status.html
```

---

## Code Generation Rules (Sharath)
1. `User` is the **abstract base** — uses `@Inheritance(SINGLE_TABLE)` with `@DiscriminatorColumn("dtype")`
2. `Request` is the **abstract base** — uses `@Inheritance(SINGLE_TABLE)` with `@DiscriminatorColumn("request_type")`
3. `RequestFactory.createRequest()` MUST handle both "BLOOD" and "ORGAN" cases
4. Factory pattern MUST be commented in service classes showing WHERE it's applied
5. Auth controller handles login/register with session management
6. Thymeleaf templates use Bootstrap 5 CDN
7. Use `jakarta.*` imports (NOT `javax.*`)
8. Service layer uses `Optional<T>` for null safety
9. **GRASP (Creator) MUST be implemented and documented:**
  - `User`/`Patient` (request owner) initiates Request creation from UI flow
  - `RequestFactory` MUST have Javadoc: `/** Factory Pattern for Request subtype creation */`
  - `RequestFactory` chooses concrete subtype (`BloodRequest` or `OrganRequest`) based on request type
  - `RequestController` receives user input and delegates subtype creation to `RequestFactory`
   - Add `@author Sharath (SRN 823)` on every class

---

## Auth Controller Endpoints
| Method | Path | Description |
|--------|------|-------------|
| GET | `/login` | Show login page |
| POST | `/login` | Process login |
| GET | `/register` | Show registration page |
| POST | `/register` | Register new user |
| POST | `/logout` | Logout user |

## Request Controller Endpoints
| Method | Path | Description |
|--------|------|-------------|
| GET | `/requests/create` | Show request creation form |
| POST | `/requests/create` | Create blood/organ request (via Factory) |
| GET | `/requests/list` | List all requests |
| GET | `/requests/{id}` | View request details |
| POST | `/requests/{id}/status` | Update request status |

---

## MySQL (reference — auto-generated by JPA)
```sql
-- users table (single table inheritance)
CREATE TABLE users (
  dtype VARCHAR(31), user_id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(255), mail VARCHAR(255), password VARCHAR(255), phone INT,
  blood_type VARCHAR(10), organ_type VARCHAR(50), availability BOOLEAN,
  required_blood_type VARCHAR(10), required_organ VARCHAR(50), urgency_level VARCHAR(20),
  admin_id INT
);

-- requests table (single table inheritance)
CREATE TABLE requests (
  request_id INT PRIMARY KEY AUTO_INCREMENT,
  request_type VARCHAR(20), request_date DATE, status VARCHAR(20),
  patient_id INT, blood_type VARCHAR(10), organ_type VARCHAR(50),
  units_required INT, units_received INT, compatibility_notes VARCHAR(500),
  FOREIGN KEY (patient_id) REFERENCES users(user_id)
);
```

---

## Navigation
- Project skill → see `.agent-skills/about-this-proejct/SKILL.md`
- Other members → `nandan-admin-donation.md`, `nandani-donor-patient.md`, `neha-inventory.md`
